module Pascal.EvalStatement where
    --evaluator for statement data type
    
import Pascal.Data

evalState :: Statement -> String
evalState (Writeln s) = s